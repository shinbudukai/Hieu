import datetime
time = datetime.datetime.now()
format = '%Y/%m/%d %I:%M:%p'
fixed_time = datetime.datetime.strptime(str(time), '%Y-%m-%d %H:%M:%S.%f')
#menu
option = input("Choose one option (What time is it ?/Timer):\n- ")
#What time is it ?
if option == "what time is it":
    print(fixed_time.strftime(format))
elif option == "what time is it ?":
    print(fixed_time.strftime(format))
elif option == "What time is it ?":
    print(fixed_time.strftime(format))
elif option == "What time is it":
    print(fixed_time.strftime(format))
#Timer:
import time
def count(t):
    while t:
        mins, secs = divmod(t, 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        print(timer, end='\r')
        time.sleep(1)
        t -= 1
    print("Time's up")
if option == "Timer":
    your_choose = input("Enter the time you want in the seconds: ")
    count(int(your_choose))
elif option == "timer":
    your_choose = input("Enter the time you want in the seconds: ")
    count(int(your_choose))

